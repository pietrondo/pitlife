<?php
if (!defined('ABSPATH')) exit;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class Dizionario_Menu_Elementor_Widget extends Widget_Base {

  public function get_name() {
    return 'dizionario_menu_widget';
  }

  public function get_title() {
    return 'Dizionario Menu';
  }

  public function get_icon() {
    return 'eicon-nav-menu';
  }

  public function get_categories() {
    return ['general'];
  }

  private function get_menus_options() {
    $menus = wp_get_nav_menus();
    $options = [0 => '— Seleziona —'];
    if (!empty($menus) && !is_wp_error($menus)) {
      foreach ($menus as $m) {
        $options[(int)$m->term_id] = $m->name;
      }
    }
    return $options;
  }

  protected function register_controls() {
    // CONTENUTO
    $this->start_controls_section('dm_section_content', [
      'label' => 'Contenuto',
      'tab' => Controls_Manager::TAB_CONTENT,
    ]);

    $this->add_control('menu_id', [
      'label' => 'Menu WordPress',
      'type' => Controls_Manager::SELECT,
      'options' => $this->get_menus_options(),
      'default' => 0,
    ]);

    $this->add_control('left_text', [
      'label' => 'Testo sinistra',
      'type' => Controls_Manager::TEXT,
      'default' => 'ARTICOLI',
    ]);

    $this->add_control('left_url', [
      'label' => 'Link sinistra',
      'type' => Controls_Manager::URL,
      'placeholder' => home_url('/'),
      'options' => ['url', 'is_external', 'nofollow'],
      'default' => ['url' => home_url('/'), 'is_external' => false, 'nofollow' => false],
    ]);

    $this->add_control('show_search', [
      'label' => 'Mostra icona cerca',
      'type' => Controls_Manager::SWITCHER,
      'label_on' => 'Sì',
      'label_off' => 'No',
      'return_value' => 'yes',
      'default' => 'yes',
    ]);

    $this->add_control('search_url', [
      'label' => 'Link icona cerca',
      'type' => Controls_Manager::TEXT,
      'default' => '',
      'description' => 'Lascia vuoto per usare /?s= (ricerca WordPress).',
      'condition' => ['show_search' => 'yes'],
    ]);

    $this->add_control('center_max', [
      'label' => 'Max width fascia centrale',
      'type' => Controls_Manager::TEXT,
      'default' => '1180px',
    ]);

    $this->add_control('breakpoint', [
      'label' => 'Breakpoint hamburger (px)',
      'type' => Controls_Manager::NUMBER,
      'min' => 320,
      'max' => 2000,
      'step' => 1,
      'default' => 860,
      'description' => 'Sotto questa larghezza scatta hamburger.',
    ]);

    $this->end_controls_section();

    // STILE
    $this->start_controls_section('dm_section_style', [
      'label' => 'Stile',
      'tab' => Controls_Manager::TAB_STYLE,
    ]);

    $this->add_control('bg_left', [
      'label' => 'Sfondo sinistra',
      'type' => Controls_Manager::COLOR,
      'default' => '#3b2a12',
    ]);

    $this->add_control('bg_center', [
      'label' => 'Sfondo centrale',
      'type' => Controls_Manager::COLOR,
      'default' => '#507a24',
    ]);

    $this->add_control('bg_right', [
      'label' => 'Sfondo destra',
      'type' => Controls_Manager::COLOR,
      'default' => '#3b2a12',
    ]);

    $this->add_control('text_color', [
      'label' => 'Colore testo',
      'type' => Controls_Manager::COLOR,
      'default' => '#ffffff',
    ]);

    $this->end_controls_section();
  }

  protected function render() {
    $s = $this->get_settings_for_display();

    $left_url = !empty($s['left_url']['url']) ? $s['left_url']['url'] : home_url('/');

    echo Dizionario_Menu_Plugin::render_menu_markup([
      'menu_id' => (int)$s['menu_id'],
      'left_text' => (string)$s['left_text'],
      'left_url' => $left_url,
      'bg_left' => (string)$s['bg_left'],
      'bg_center' => (string)$s['bg_center'],
      'bg_right' => (string)$s['bg_right'],
      'text_color' => (string)$s['text_color'],
      'center_max' => (string)$s['center_max'],
      'show_search' => ($s['show_search'] === 'yes'),
      'search_url' => (string)$s['search_url'],
      'breakpoint' => (int)$s['breakpoint'],
    ]);
  }

  protected function content_template() {
    // Rendering live in editor: Elementor usa PHP render.
  }
}
