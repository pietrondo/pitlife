<?php
/**
 * Plugin Name: Dizionario Menu
 * Description: Menu a barra stile "fascia" con hamburger su mobile. Shortcode + Widget Elementor configurabile.
 * Version: 1.1.0
 * Author: You
 */

if (!defined('ABSPATH')) exit;

final class Dizionario_Menu_Plugin {
  const VERSION = '1.1.0';
  const SHORTCODE = 'dizionario_menu';

  public function __construct() {
    add_action('wp_enqueue_scripts', [$this, 'register_assets']);
    add_shortcode(self::SHORTCODE, [$this, 'render_shortcode']);

    // Elementor widget
    add_action('plugins_loaded', [$this, 'maybe_register_elementor_widget']);
  }

  public function register_assets() {
    $css = $this->get_css();
    $js  = $this->get_js();

    wp_register_style('dizionario-menu', false, [], self::VERSION);
    wp_enqueue_style('dizionario-menu');
    wp_add_inline_style('dizionario-menu', $css);

    wp_register_script('dizionario-menu', false, [], self::VERSION, true);
    wp_enqueue_script('dizionario-menu');
    wp_add_inline_script('dizionario-menu', $js);
  }

  public function maybe_register_elementor_widget() {
    if (!did_action('elementor/loaded')) return;

    // Widget file
    $widget_file = plugin_dir_path(__FILE__) . 'widgets/class-dizionario-menu-elementor-widget.php';
    if (file_exists($widget_file)) {
      require_once $widget_file;
    }

    // Registra widget
    add_action('elementor/widgets/register', function($widgets_manager){
      if (class_exists('Dizionario_Menu_Elementor_Widget')) {
        $widgets_manager->register(new \Dizionario_Menu_Elementor_Widget());
      }
    });
  }

  public static function render_menu_markup($settings = []) {
    $defaults = [
      'menu_id' => 0,
      'left_text' => 'ARTICOLI',
      'left_url' => home_url('/'),
      'bg_left' => '#3b2a12',
      'bg_center' => '#507a24',
      'bg_right' => '#3b2a12',
      'text_color' => '#ffffff',
      'center_max' => '1180px',
      'show_search' => true,
      'search_url' => '',
      'breakpoint' => 860,
    ];
    $s = array_merge($defaults, is_array($settings) ? $settings : []);

    $uid = 'dm_' . wp_generate_password(6, false, false);

    $menu_args = [
      'container'      => false,
      'echo'           => false,
      'fallback_cb'    => '__return_empty_string',
      'menu_class'     => 'dm-nav__list',
      'depth'          => 2,
      'link_before'    => '<span class="dm-nav__linktext">',
      'link_after'     => '</span>',
      'items_wrap'     => '<ul class="%2$s">%3$s</ul>',
    ];

    if (!empty($s['menu_id'])) {
      $menu_args['menu'] = (int)$s['menu_id'];
    }

    $menu_html = wp_nav_menu($menu_args);
    if (!$menu_html) {
      $menu_html = '<ul class="dm-nav__list"><li><a href="#">Configura un menu WordPress</a></li></ul>';
    }

    $search_url = trim((string)$s['search_url']);
    if ($search_url === '') {
      $search_url = home_url('/?s=');
    }

    ob_start(); ?>
    <nav class="dm-nav"
         id="<?php echo esc_attr($uid); ?>"
         data-dm-breakpoint="<?php echo (int)$s['breakpoint']; ?>"
         style="
           --dm-bg-left: <?php echo esc_attr($s['bg_left']); ?>;
           --dm-bg-center: <?php echo esc_attr($s['bg_center']); ?>;
           --dm-bg-right: <?php echo esc_attr($s['bg_right']); ?>;
           --dm-text: <?php echo esc_attr($s['text_color']); ?>;
           --dm-center-max: <?php echo esc_attr($s['center_max']); ?>;
         "
         aria-label="Menu">
      <div class="dm-nav__row">

        <div class="dm-nav__left">
          <a class="dm-nav__leftlink" href="<?php echo esc_url($s['left_url']); ?>">
            <?php echo esc_html($s['left_text']); ?>
          </a>
        </div>

        <div class="dm-nav__center">
          <button class="dm-nav__burger" type="button" aria-expanded="false" aria-controls="<?php echo esc_attr($uid); ?>_panel">
            <span class="dm-nav__burgericon" aria-hidden="true"></span>
            <span class="dm-sr-only">Apri menu</span>
          </button>

          <div class="dm-nav__panel" id="<?php echo esc_attr($uid); ?>_panel">
            <?php echo $menu_html; ?>
          </div>
        </div>

        <div class="dm-nav__right">
          <?php if (!empty($s['show_search'])): ?>
            <a class="dm-nav__search" href="<?php echo esc_url($search_url); ?>" aria-label="Cerca">
              <svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true">
                <path fill="currentColor" d="M10 18a8 8 0 1 1 5.293-14.293A8 8 0 0 1 10 18Zm11.707 2.293-5.387-5.387A9.95 9.95 0 0 0 20 10a10 10 0 1 0-10 10 9.95 9.95 0 0 0 4.906-1.68l5.387 5.387a1 1 0 0 0 1.414-1.414Z"/>
              </svg>
            </a>
          <?php endif; ?>
        </div>

      </div>
    </nav>
    <?php
    return ob_get_clean();
  }

  public function render_shortcode($atts) {
    $atts = shortcode_atts([
      'menu' => '',                 // nome/slug/ID
      'left_text' => 'ARTICOLI',
      'left_url' => home_url('/'),
      'bg_left' => '#3b2a12',
      'bg_center' => '#507a24',
      'bg_right' => '#3b2a12',
      'text_color' => '#ffffff',
      'center_max' => '1180px',
      'show_search' => '1',
      'search_url' => '',
      'breakpoint' => '860',
    ], $atts, self::SHORTCODE);

    $menu_id = 0;
    if ($atts['menu'] !== '') {
      if (is_numeric($atts['menu'])) {
        $menu_id = (int)$atts['menu'];
      } else {
        $obj = wp_get_nav_menu_object($atts['menu']);
        if ($obj && !is_wp_error($obj)) $menu_id = (int)$obj->term_id;
      }
    }

    return self::render_menu_markup([
      'menu_id' => $menu_id,
      'left_text' => $atts['left_text'],
      'left_url' => $atts['left_url'],
      'bg_left' => $atts['bg_left'],
      'bg_center' => $atts['bg_center'],
      'bg_right' => $atts['bg_right'],
      'text_color' => $atts['text_color'],
      'center_max' => $atts['center_max'],
      'show_search' => ($atts['show_search'] === '1' || $atts['show_search'] === 'true'),
      'search_url' => $atts['search_url'],
      'breakpoint' => (int)$atts['breakpoint'],
    ]);
  }

  private function get_css() {
    return <<<CSS
.dm-sr-only{
  position:absolute!important;width:1px!important;height:1px!important;padding:0!important;margin:-1px!important;
  overflow:hidden!important;clip:rect(0,0,0,0)!important;white-space:nowrap!important;border:0!important;
}

.dm-nav{width:100%;color:var(--dm-text);font-family:inherit; position:relative; z-index: 20;}
.dm-nav__row{display:flex;width:100%;min-height:56px;}
.dm-nav__left,.dm-nav__right{
  flex:0 0 auto;display:flex;align-items:center;padding:0 18px;background:var(--dm-bg-left);
}
.dm-nav__right{background:var(--dm-bg-right);margin-left:auto;}
.dm-nav__leftlink{
  color:var(--dm-text);text-decoration:none;font-weight:600;letter-spacing:.5px;text-transform:uppercase;font-size:14px;
}
.dm-nav__center{flex:1 1 auto;background:var(--dm-bg-center);display:flex;align-items:center;justify-content:center;}
.dm-nav__panel{width:min(100%, var(--dm-center-max));padding:0 14px;}

.dm-nav__list{
  list-style:none;display:flex;align-items:center;justify-content:space-between;gap:18px;margin:0;padding:0;
}
.dm-nav__list li{margin:0;padding:0;position:relative;}
.dm-nav__list a{
  color:var(--dm-text);text-decoration:none;font-weight:600;text-transform:uppercase;font-size:14px;
  letter-spacing:.4px;display:inline-flex;align-items:center;padding:12px 4px;line-height:1;
}
.dm-nav__list a:hover{opacity:.85;}

.dm-nav__burger{display:none;border:0;background:transparent;padding:10px;cursor:pointer;color:var(--dm-text);}
.dm-nav__burgericon{display:block;width:22px;height:2px;background:currentColor;position:relative;}
.dm-nav__burgericon:before,.dm-nav__burgericon:after{
  content:"";position:absolute;left:0;width:22px;height:2px;background:currentColor;
}
.dm-nav__burgericon:before{top:-7px;}
.dm-nav__burgericon:after{top:7px;}

.dm-nav__search{color:var(--dm-text);display:flex;align-items:center;justify-content:center;text-decoration:none;opacity:.95;}
.dm-nav__search:hover{opacity:.8;}

/* Dropdown livello 2 */
.dm-nav__list .sub-menu{
  display:none;position:absolute;top:100%;left:0;min-width:220px;background:var(--dm-bg-center);
  padding:10px;border-radius:10px;box-shadow:0 10px 30px rgba(0,0,0,.25);z-index:50;
}
.dm-nav__list li:hover > .sub-menu{display:block;}
.dm-nav__list .sub-menu li a{
  width:100%;padding:10px 8px;font-size:13px;text-transform:none;font-weight:600;
}

/* Mobile class (gestita via JS con breakpoint configurabile) */
.dm-nav.dm-is-mobile .dm-nav__row{min-height:54px;}
.dm-nav.dm-is-mobile .dm-nav__panel{width:100%;padding:0;}
.dm-nav.dm-is-mobile .dm-nav__burger{
  display:flex;align-items:center;justify-content:center;margin-left:6px;
}
.dm-nav.dm-is-mobile .dm-nav__center{position:relative;justify-content:flex-start;}
.dm-nav.dm-is-mobile .dm-nav__panel{
  display:none;position:absolute;left:0;right:0;top:54px;background:var(--dm-bg-center);padding:12px 14px 18px;
}
.dm-nav.dm-is-mobile.dm-open .dm-nav__panel{display:block;}
.dm-nav.dm-is-mobile .dm-nav__list{flex-direction:column;align-items:flex-start;gap:10px;}
.dm-nav.dm-is-mobile .dm-nav__list a{width:100%;padding:10px 6px;font-size:14px;}
.dm-nav.dm-is-mobile .dm-nav__list .sub-menu{
  position:static;display:block;min-width:0;box-shadow:none;padding:4px 0 0;border-radius:0;
}
.dm-nav.dm-is-mobile .dm-nav__list .sub-menu a{opacity:.95;padding-left:18px;font-size:13px;}
CSS;
  }

  private function get_js() {
    return <<<JS
(function(){
  function setMobileClass(nav){
    var bp = parseInt(nav.getAttribute('data-dm-breakpoint') || '860', 10);
    var isMobile = window.matchMedia('(max-width: ' + bp + 'px)').matches;
    nav.classList.toggle('dm-is-mobile', isMobile);
    if(!isMobile){
      nav.classList.remove('dm-open');
      var burger = nav.querySelector('.dm-nav__burger');
      if (burger) burger.setAttribute('aria-expanded', 'false');
    }
  }

  function initOne(nav){
    var burger = nav.querySelector('.dm-nav__burger');
    var panel  = nav.querySelector('.dm-nav__panel');
    if(!burger || !panel) return;

    setMobileClass(nav);
    window.addEventListener('resize', function(){ setMobileClass(nav); });

    burger.addEventListener('click', function(){
      if(!nav.classList.contains('dm-is-mobile')) return;
      var isOpen = nav.classList.toggle('dm-open');
      burger.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });

    document.addEventListener('click', function(e){
      if(!nav.classList.contains('dm-open')) return;
      if(nav.contains(e.target)) return;
      nav.classList.remove('dm-open');
      burger.setAttribute('aria-expanded', 'false');
    });

    document.addEventListener('keydown', function(e){
      if(e.key !== 'Escape') return;
      if(!nav.classList.contains('dm-open')) return;
      nav.classList.remove('dm-open');
      burger.setAttribute('aria-expanded', 'false');
    });
  }

  function init(){
    document.querySelectorAll('.dm-nav').forEach(initOne);
  }

  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
JS;
  }
}

new Dizionario_Menu_Plugin();
